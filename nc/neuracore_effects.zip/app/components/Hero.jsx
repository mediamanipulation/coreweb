// Hero with blur + wobble + CTA brighten placeholder
export default function Hero(){
  return <div>Hero</div>;
}