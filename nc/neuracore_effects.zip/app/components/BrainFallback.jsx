// BrainFallback with bloom pulse placeholder
export default function BrainFallback(){
  return null;
}