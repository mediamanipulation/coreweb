// NeuralBrainCanvas with rim-light overlay placeholder
export default function NeuralBrainCanvas(){
  return null;
}